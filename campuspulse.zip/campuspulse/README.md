# CampusPulse

Generated with InspoAI Agentic UI.

Each file is a self-contained HTML screen (Tailwind CDN + Alpine.js + Chart.js via CDN) — open directly in a browser, no build step required.

| File | Screen |
|---|---|
| 01-*.html | Student Home |
| 02-*.html | Explore Events |
| 03-*.html | Event Details |
| 04-*.html | Team Registration |
| 05-*.html | Payment Submission |
| 06-*.html | My Registrations |
